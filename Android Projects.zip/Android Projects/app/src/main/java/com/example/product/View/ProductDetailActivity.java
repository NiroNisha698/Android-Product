package com.example.product.View;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


import com.bumptech.glide.Glide;

import com.example.product.Methods;
import com.example.product.Model.Product;
import com.example.product.R;
import com.example.product.RetrofitClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductDetailActivity extends AppCompatActivity {
    private static final String TAG= "ProductDetailActivity";
    public TextView mtitle,mPrice,description;
    Button checkout;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);
        mtitle = findViewById(R.id.title);
        mPrice = findViewById(R.id.price);
        description = findViewById(R.id.description);
        checkout = findViewById(R.id.checkout);
        imageView = findViewById(R.id.product_image);

        
        getProductDetails();
    }

    private void getProductDetails() {
        Methods methods = RetrofitClient.getRetrofitInstance().create(Methods.class);
        Call<Product> call= methods.getDetail();

       call.enqueue(new Callback<Product>() {
           @Override
           public void onResponse(Call<Product> call, Response<Product> response) {
               int statusCode = response.code();
               if(statusCode ==200){



                       String title= response.body().getTitle();
                       String price= response.body().getPrice();
                       String desc= response.body().getDescription();
                       String imgURL= response.body().getImages();

                       mtitle.setText(title);
                       mPrice.setText(price);
                       description.setText(desc);
                       Glide.with(ProductDetailActivity.this).load(imgURL).into(imageView);
                       checkout.setText("CHECKOUT");

               }
           }

           @Override
           public void onFailure(Call<Product> call, Throwable t) {
               Log.e(TAG,"onFailure() "+ t.getMessage());
           }
       });

    }
}