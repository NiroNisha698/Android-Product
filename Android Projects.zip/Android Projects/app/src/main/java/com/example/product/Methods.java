package com.example.product;

import com.example.product.Model.Product;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Methods {

    @GET("products")
    Call<List<Product>> getAllProduct();

    @GET("featured")
    Call<Product> getDetail();
}
