package com.example.product;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.ColorSpace;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.product.Model.Product;
import com.example.product.View.ProductAdapter;
import com.example.product.View.ProductDetailActivity;
import com.example.product.View.ProductDetails;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements ProductAdapter.ItemClickListener {
    private static final String TAG= "MainActivity";

    Button mProduct;
    RecyclerView recyclerView;
    private ProductAdapter mAdapter;
    ImageView main_image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        main_image = findViewById(R.id.main_image);
        mAdapter = new ProductAdapter();
        mAdapter.setClickListener(this);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        mLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        getDataFromAPI();

    }

    private void getDataFromAPI() {
        Methods methods = RetrofitClient.getRetrofitInstance().create(Methods.class);
        Call<List<Product>> call= methods.getAllProduct();

        call.enqueue(new Callback<List<Product>>() {
            @Override
            public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
                int statusCode = response.code();
                if(statusCode == 200){
                    ArrayList<Product> listProduct = (ArrayList<Product>) response.body();
                    mAdapter.setData(listProduct);

                    String url = listProduct.get(2).getImages();
                    Glide.with(MainActivity.this).load(url).into(main_image);

                }
            }

            @Override
            public void onFailure(Call<List<Product>> call, Throwable t) {
                Log.e(TAG,"onFailure() "+ t.getMessage());
            }
        });

    }

    @Override
    public void onItemClick() {
        startActivity(new Intent(MainActivity.this, ProductDetailActivity.class));
    }
}