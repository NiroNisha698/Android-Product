package com.example.product.View;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.product.Model.Product;
import com.example.product.R;
import java.util.ArrayList;

public class ProductAdapter extends  RecyclerView.Adapter<ProductAdapter.ViewHolder> {

    ArrayList<Product> mData;
    private ItemClickListener mClickListener;

    public void setData(ArrayList<Product> listProduct) {
        this.mData = listProduct;
        notifyDataSetChanged();

    }

    @Override
    public ViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_adapter,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder( ProductAdapter.ViewHolder holder, int position) {
            Product product = mData.get(position);
            holder.mTextTitle.setText(product.getTitle());
            holder.mTextPrice.setText(product.getPrice());

        Glide.with(holder.itemView).load(product.getImages()).into(holder.mViewProduct);
    }

    @Override
    public int getItemCount() {
        return mData == null ? 0 : mData.size();
    }




    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView mTextTitle;
        TextView mTextPrice;
        ImageView mViewProduct;
        public ViewHolder(View itemView) {
            super(itemView);
            mTextTitle = itemView.findViewById(R.id.title);
            mTextPrice = itemView.findViewById(R.id.price);
            mViewProduct = itemView.findViewById(R.id.image_product);
            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
           mClickListener.onItemClick();
        }
    }

    public interface ItemClickListener{
        void onItemClick();
    }
    public void setClickListener(ItemClickListener itemClickListener){
        this.mClickListener = itemClickListener;
    }
}
